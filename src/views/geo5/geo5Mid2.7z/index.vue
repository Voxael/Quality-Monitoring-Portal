<template>
  <div class="geo5Mid2">
    <div>
      <div class="d-flex pt-2 pl-2">
        <div class="d-flex">
          <span class="fs-xl text mx-2 mt-1">质量信息仪表盘</span>
        </div>
      </div>
      <!-- <div class="down">
        <div class="percent">
          <div class="item bg-color-black">
            <span>今日任务通过率</span>
            <chart :tips="rate[0].tips" :colorObj="rate[0].colorData" />
          </div>
          <div class="item bg-color-black">
            <span>今日任务达标率</span>
            <chart :tips="rate[1].tips" :colorObj="rate[1].colorData" />
          </div>
        </div>
      </div> -->
    </div>
  </div>
</template>

<script>
import { defineComponent,reactive,onMounted } from "vue";
import Chart from "./chart/index";
export default defineComponent({
  components: {
    Chart,
  },

  setup() {
    // 下层数据
    const titleDate = [
      {
        number: 1020,
        text: '今年累计任务建次数'
      },
      {
        number: 18,
        text: '本月累计任务次数'
      },
      {
        number: 4,
        text: '今日累计任务次数'
      },
      {
        number: 71,
        text: '今年失败任务次数'
      },
      {
        number: 949,
        text: '今年失败成功次数'
      },
      {
        number: 811,
        text: '今年达标任务个数'
      },
    ]
    const titleItem = reactive([])

    // 初始化数据
    onMounted(() => {
      setData()
    })

    const ranking = reactive({
      data: [
        {
          name: '周口',
          value: 55
        },
        {
          name: '南阳',
          value: 120
        },
        {
          name: '西峡',
          value: 78
        },
        {
          name: '驻马店',
          value: 66
        },
        {
          name: '新乡',
          value: 80
        },
        {
          name: '新乡2',
          value: 80
        },
        {
          name: '新乡3',
          value: 80
        },
        {
          name: '新乡4',
          value: 80
        },
        {
          name: '新乡5',
          value: 80
        },
        {
          name: '新乡6',
          value: 80
        }
      ],
      carousel: 'single',
      unit: '人'
    })

    const water = reactive({
      data: [24, 45],
      shape: 'roundRect',
      formatter: '{value}%',
      waveNum: 3
    })

    const rate = reactive([
      {
        id: 'centerRate1',
        tips: 60,
        colorData: {
          textStyle: '#3fc0fb',
          series: {
            color: ['#00bcd44a', 'transparent'],
            dataColor: {
              normal: '#03a9f4',
              shadowColor: '#97e2f5'
            }
          }
        }
      },
      {
        id: 'centerRate2',
        tips: 40,
        colorData: {
          textStyle: '#67e0e3',
          series: {
            color: ['#faf3a378', 'transparent'],
            dataColor: {
              normal: '#ff9800',
              shadowColor: '#fcebad'
            }
          }
        }
      }
    ])

    // 设置数据
    const setData = () => {
      titleDate.map(e => {
        titleItem.push({
          title: e.text,
          config: {
            number: [e.number],
            toFixed: 1,
            textAlign: 'left',
            content: '{nt}',
            style: {
              fontSize: 26
            }
          }
        })
      })
    }
    return {
      titleItem,
      ranking,
      water,
      rate
    }
  }
});
</script>

<style lang="scss" class>
$box-height: 300px;
$box-width: 620px;
.geo5Mid2 {
  //padding: 14px 16px;
  height: $box-height;
  width: $box-width;
  border-radius: 5px;
  .bg-color-black {
    height: $box-height - 30px;
    border-radius: 10px;
  }
  .text {
    color: bisque;
    font-size: 20px;
  }

  .chart {
    position: relative;
    //top: -15px;
    // left: 20px;
  }

  .down {
    padding: 6px 4px;
    padding-bottom: 0;
    width: 100%;
    display: flex;
    height: 255px;
    justify-content: space-between;
    .bg-color-black {
      border-radius: 5px;
    }
    
    .percent {
      width: 40%;
      display: flex;
      flex-wrap: wrap;
      .item {
        width: 50%;
        height: 120px;
        span {
          margin-top: 8px;
          font-size: 14px;
          display: flex;
          justify-content: center;
        }
      }
      
    }
  }
}
</style>
